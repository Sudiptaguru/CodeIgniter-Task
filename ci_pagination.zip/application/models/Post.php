<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Post extends CI_Model {

    function getrow(){
        $this->db->select('*');
        $records = $this->db->get('users');
        $users = $records->result_array();
        return $users;
    }

}