<!doctype html>
<html lang="en">

<head>
    <title> Codeigniter Ajax CRUD | Programming Fields </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta name="csrf-token" content="" />
</head>

<body>
    <div class="container mt-5">
        <h4 class="text-center font-weight-bold"> Codeigniter Ajax CRUD Application - Programming Fields </h4>

        <style>
            svg.w-5.h-5 {
                width: 25px !important;
            }

            span.relative.z-0.inline-flex.shadow-sm.rounded-md {
                float: right !important;
            }
        </style>

        <div class="row">
            <div class="col-xl-6">
                <div id="result"></div>
            </div>

            <div class="col-xl-6 text-right">
                <a href="javascript:void(0);" data-target="#addPostModal" data-toggle="modal" data-action="add" class="btn btn-success"> Add New </a>
            </div>
        </div>

        <table class="table table-striped mt-4">
            <thead>
                <th> Post Id </th>
                <th> Title </th>
                <th> Description </th>
                <th> Action </th>
            </thead>

            <tbody>
                @foreach ($posts as $post)
                <tr>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td>
                        <a href="javascript:void(0);" data-toggle="modal" data-target="#addPostModal" data-id="" data-title="" data-description="" data-action="view" class="btn btn-info btn-sm"> View </a>
                        <a href="javascript:void(0);" data-toggle="modal" data-target="#addPostModal" data-id="" data-title="" data-description="" data-action="edit" class="btn btn-success btn-sm"> Edit </a>
                        <a href="javascript:void(0);" onclick="deletePost()" class="btn btn-danger btn-sm"> Delete </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>


        <!-- Create post modal -->
        <div class="modal fade" id="addPostModal" tabindex="-1" role="dialog" aria-labelledby="addPostModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">

                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addPostModalLabel"> Create Post </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true"> × </span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form method="POST" id="postForm">
                            <input type="hidden" id="id_hidden" name="id" />
                            <div class="form-group">
                                <label for="title"> Title <span class="text-danger">*</span></label>
                                <input type="text" name="title" id="title" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="title"> Description <span class="text-danger">*</span></label>
                                <textarea name="description" id="description" class="form-control"></textarea>
                            </div>
                        </form>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" id="createBtn" class="btn btn-primary"> Save </button>
                    </div>

                    <div class="result"></div>

                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="<?php echo base_url(); ?>js/script.js"></script>
</body>

</html>