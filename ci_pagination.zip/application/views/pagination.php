<!DOCTYPE html>
<html lang="en">
<head>
  <title>Codeigniter  Pagination</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <center><h3><u>Users Data</u> </h3></center><br>  
 <table class="table table-bordered table-striped">  
<thead>  
<tr bgcolor="silver">  
<th>#</th>
<th>Name</th>
<th>Email Id</th>
 <th>Mobile No</th>
<th>Reg. Date</th>
</tr>  
<thead>  
<tbody>  
<?php 
foreach ($users as $result){ ?> 
             <tr>
                     <td><?php echo $result->id;?></td>
                    <td><?php echo $result->fullName; ?></td>
                    <td><?php echo $result->emailId; ?></td>
                    <td><?php echo $result->mobileNumber; ?></td>
                     <td><?php echo $result->regDate; ?></td>
            </tr>
<?php  } ?>
</tbody>  
</table>  
 <p><?php echo $links; ?></p>
</div>
</body>
</html>
