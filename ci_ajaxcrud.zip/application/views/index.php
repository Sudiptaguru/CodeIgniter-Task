<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
    <style>
        svg.w-5.h-5 {
            width: 25px !important;
        }

        span.relative.z-0.inline-flex.shadow-sm.rounded-md {
            float: right !important;
        }
    </style>
    <script type="text/javascript" class="init">
        $(document).ready(function() {
            $('#example').DataTable({
                "pagingType": "full_numbers"
            });
        });
    </script>
</head>

<body class="wide comments example">
    <div class="container mt-5">

        <div class="row">
            <div class="col-xl-6">
                <div id="result"></div>
            </div>

            <div class="col-xl-6 text-right">
                <a href="javascript:void(0);" data-target="#addPostModal" data-toggle="modal" data-action="add" class="btn btn-success"> Add New </a>
            </div>
        </div>
        <table id="example" class="table table-striped mt-4">
            <thead>
                <tr bgcolor="silver">
                    <th>#</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th> Action </th>
                </tr>
                <thead>
                <tbody>
                    <?php
                    $count = 1;
                    foreach ($users as $result) {
                    ?>
                        <tr>
                            <td><?php echo $count; ?></td>
                            <td><?php echo $result->title; ?></td>
                            <td><?php echo $result->description; ?></td>
                            <td>
                                <a href="javascript:void(0);" data-toggle="modal" data-target="#addPostModal" data-id="<?php echo $result->id; ?>" data-title="<?php echo $result->title; ?>" data-description="<?php echo $result->description; ?>" data-action="view" class="btn btn-info btn-sm"> View </a>
                                <a href="javascript:void(0);" data-toggle="modal" data-target="#addPostModal" data-id="<?php echo $result->id; ?>" data-title="<?php echo $result->title; ?>" data-description="<?php echo $result->description; ?>" data-action="edit" class="btn btn-success btn-sm"> Edit </a>
                                <a href="javascript:void(0);" data-toggle="modal" data-target="#deletePostModal" data-id="<?php echo $result->id; ?>" data-status="<?php echo $result->status; ?>" data-action="delete" class="btn btn-danger btn-sm"> Delete </a>
                            </td>
                        </tr>
                    <?php $count++;
                    } ?>
                </tbody>
        </table>

        <!-- Create post modal -->
        <div class="modal fade" id="addPostModal" tabindex="-1" role="dialog" aria-labelledby="addPostModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">

                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addPostModalLabel"> Create Post </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true"> × </span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form method="POST" id="postForm">
                            <input type="hidden" id="id_hidden" name="id" />
                            <div class="form-group">
                                <label for="title"> Title <span class="text-danger">*</span></label>
                                <input type="text" name="title" id="title" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="title"> Description <span class="text-danger">*</span></label>
                                <textarea name="description" id="description" class="form-control"></textarea>
                            </div>
                        </form>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" id="createBtn" class="btn btn-primary"> Save </button>
                    </div>

                    <div class="result"></div>

                </div>
            </div>
        </div>

        <!-- Delete post modal -->
        <div class="modal fade" id="deletePostModal" tabindex="-1" role="dialog" aria-labelledby="deletePostModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">

                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deletePostModalLabel"> Delete Post </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true"> × </span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form method="POST" id="postForm1">
                            <input type="hidden" id="id_hidden1" name="id1" />
                            <input type="hidden" id="status" name="status" />
                            Are you sure ?
                        </form>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> Close </button>
                        <button type="submit" id="deleteBtn" class="btn btn-danger"> Delete </button>
                    </div>

                    <div class="result"></div>

                </div>
            </div>
        </div>
    </div>
</body>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="<?php echo base_url(); ?>assets/js/script.js"></script>

</html>