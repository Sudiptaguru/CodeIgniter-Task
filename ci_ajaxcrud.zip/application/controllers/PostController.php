<?php
defined('BASEPATH') or exit('No direct script access allowed');

class PostController extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->model('Post');
        $this->load->library("pagination");
    }
    public function index()
    {
        // $this->pageConfig();
        // $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        // $data["links"] = $this->pagination->create_links();
        // print_r($data["links"]); exit;
        $data['users'] = $this->Post->getUsers('posts');
        $this->load->view('index', $data);
    }

    public function pageConfig()
    {
        $config = array();
        $config["base_url"] = base_url() . "PostController/index";
        $config["total_rows"] = $this->Post->getCount('posts');
        $config["per_page"] = 3;
        $config["uri_segment"] = 3;
        $config['full_tag_open'] = "<ul class='pagination'>";
        $config['full_tag_close'] = '</ul>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['prev_link'] = '<i class="fa fa-long-arrow-left"></i>Previous Page';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next Page<i class="fa fa-long-arrow-right"></i>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $this->per_page = $config["per_page"];
        $this->pagination->initialize($config);
    }

    public function store()
	{
		$data['title'] = $this->input->post('title');
		$data['description'] = $this->input->post('description');

		$post = $this->Post->insert('posts', $data);
        // print_r($post); exit;
		if (!is_null($post)) {
            echo json_encode(['success'=>'Record added successfully.']);
        } else {
            $errors = validation_errors();
            echo json_encode(['error'=>$errors]);
        }
	}

    public function update()
	{
		$id=$this->input->post('id');
		$data['title']=$this->input->post('title');
		$data['description']=$this->input->post('description');
		$post=$this->Post->update('posts', $data, $id);
		if (!is_null($post)) {
            echo json_encode(['success'=>'Record added successfully.']);
        } else {
            $errors = validation_errors();
            echo json_encode(['error'=>$errors]);
        }
	}

    public function delete()
	{
		$id=$this->input->post('id');
		$data['status']='1';
		$post=$this->Post->delete('posts', $data, $id);
		if (!is_null($post)) {
            echo json_encode(['success'=>'Record deleted successfully.']);
        } else {
            $errors = validation_errors();
            echo json_encode(['error'=>$errors]);
        }
	}
}
