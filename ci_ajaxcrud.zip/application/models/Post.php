<?php 
class Post extends CI_Model{    
    // private $table = 'posts';    
    // public function getCount($table) {
    //     return $this->db->where('status',0)->count_all($table);
    // }
    public function getUsers($table) {
        $this->db->where('status',0);
        $query = $this->db->get($table);
        return $query->result();
    }
    public function insert($table, $data)
	{
		$result = $this->db->insert($table, $data);
		return $result;
	}
    public function update($table, $data, $id)
	{
		$result = $this->db->where('id', $id)->update($table, $data);
		return $result;
	}
    public function delete($table, $data, $id)
	{
		$result = $this->db->where('id', $id)->update($table, $data);
		return $result;
	}
}
?>