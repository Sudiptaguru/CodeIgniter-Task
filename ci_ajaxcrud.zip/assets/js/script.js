
//----- [ button click function ] ----------
$("#createBtn").click(function (event) {
    event.preventDefault();
    $(".error").remove();
    $(".alert").remove();

    var title = $("#title").val();
    var description = $("#description").val();

    if (title == "") {
        $("#title").after('<span class="text-danger error"> Title is required </span>');

    }

    if (description == "") {
        $("#description").after('<span class="text-danger error"> Description is required </span>');
        return false;
    }

    var form_data = $("#postForm").serialize();

    // if post id exist
    if ($("#id_hidden").val() != "") {
        updatePost(form_data);
    }

    // else create post
    else {
        createPost(form_data);
    }
});

$("#deleteBtn").click(function (event) {
    event.preventDefault();
    $(".error").remove();
    $(".alert").remove();

    var status = $("#status").val();
    var form_data1 = $("#postForm1").serialize();

    // if post id exist
    if ($("#id_hidden1").val() != "") {
        deletePost(form_data1);
    }
});


// create new post
function createPost(form_data) {
    $.ajax({
        url: '/ci_ajaxcrud/PostController/store',
        method: 'post',
        data: form_data,
        dataType: 'json',

        // beforeSend:function() {
        //     $("#createBtn").addClass("disabled");
        //     $("#createBtn").text("Processing..");
        // },

        success: function (res) {
            // $("#createBtn").removeClass("disabled");
            $("#createBtn").text("Save");

            if ($.isEmptyObject(res.error)) {
                // $(".result").html("<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + res.message+ "</div>");
                location.reload();
            }

            else {
                $(".result").html("<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + 'Data has been added successfullly' + "</div>");
            }
        }
    });
}

// update post
function updatePost() {
    var id = $("#id_hidden").val();
    var title = $("#title").val();
    var description = $("#description").val();
    // alert(title);
    // $.ajax({
    //     url: '/ci_ajaxcrud/PostController/update',
    //     method: 'post',
    //     data: form_data,
    //     dataType: 'json',

    //     // beforeSend:function() {
    //     //     $("#createBtn").addClass("disabled");
    //     //     $("#createBtn").text("Processing..");
    //     // },

    //     success:function(res) {
    //         // $("#createBtn").removeClass("disabled");
    //         $("#createBtn").text("Update");

    //         if($.isEmptyObject(res.error)){
    //             // $(".result").html("<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + res.message+ "</div>");
    //             // $("#addPostModal").modal("hide");
    //             // $('.toast').toast('show');
    //             location.reload();
    //         }

    //         else{
    //             $(".result").html("<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + res.message+ "</div>");
    //         }
    //     }
    // });
    $.ajax({
        url: '/ci_ajaxcrud/PostController/update',
        method: 'post',
        dataType: 'json',
        // data: form_data,
        data: { id: id, title: title, description: description },
        success: function (res) {
            if ($.isEmptyObject(res.error)) {
                $(".result").html("<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + 'Data has been updated successfullly' + "</div>");
                // location.reload();
            }

            else {
                $(".result").html("<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + 'Invalid Data' + "</div>");
            }
        }
    });
}

// ---------- [ Delete post ] ----------------
function deletePost(form_data1) {
    var id = $("#id_hidden1").val();
    var status = $("#status").val();
    $.ajax({
        url: '/ci_ajaxcrud/PostController/delete',
        method: 'post',
        dataType: 'json',
        // data: form_data,
        data: { id: id, status: status },
        success: function (res) {
            if ($.isEmptyObject(res.error)) {
                // $(".result").html("<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + 'Data has been Deleted successfullly' + "</div>");
                location.reload();
            }

            else {
                $(".result").html("<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + 'Some problem occured' + "</div>");
            }
        }
    });
}

$('#addPostModal').on('shown.bs.modal', function (e) {
    var id = $(e.relatedTarget).data('id');
    var title = $(e.relatedTarget).data('title');
    var description = $(e.relatedTarget).data('description');
    var action = $(e.relatedTarget).data('action');

    if (action !== undefined) {
        if (action === "add") {

            // // set modal title
            // $(".modal-title").html("Post Detail");

            // // pass data to input fields
            // $("#title").attr("readonly", "true");
            $("#title").val('');

            // $("#description").attr("readonly", "true");
            $("#description").val('');
            $(".alert-success").hide();

            // hide button
            $("#createBtn").text("Save");
        }

        if (action === "view") {

            // set modal title
            $(".modal-title").html("Post Detail");

            // pass data to input fields
            $("#title").attr("readonly", "true");
            $("#title").val(title);

            $("#description").attr("readonly", "true");
            $("#description").val(description);

            // hide button
            $("#createBtn").addClass("d-none");
        }


        if (action === "edit") {
            $("#title").removeAttr("readonly");
            $("#description").removeAttr("readonly");

            // set modal title
            $(".modal-title").html("Update Post");

            $("#createBtn").text("Update");

            // pass data to input fields
            $("#id_hidden").val(id);
            $("#title").val(title);
            $("#description").val(description);

            // return false;

            // // hide button
            $("#createBtn").removeClass("d-none");
        }
    }

    else {
        $(".modal-title").html("Create Post");

        // pass data to input fields
        $("#title").removeAttr("readonly");
        $("#title").val("");

        $("#description").removeAttr("readonly");
        $("#description").val("");

        // hide button
        $("#createBtn").removeClass("d-none");
    }
});

$('#deletePostModal').on('shown.bs.modal', function (e) {
    var id = $(e.relatedTarget).data('id');
    var status = $(e.relatedTarget).data('status');
    var action = $(e.relatedTarget).data('action');

    if (action !== undefined) {
        if (action === "delete") {
            $("#status").removeAttr("readonly");

            // set modal title
            $(".modal-title").html("Delete Post");

            $("#deleteBtn").text("Delete");

            // pass data to input fields
            $("#id_hidden1").val(id);
            $("#status").val(status);

            // return false;

            // // hide button
            $("#deleteBtn").removeClass("d-none");
        }
    }

    else {
        $(".modal-title").html("Delete Post");

        // pass data to input fields
        $("#status").removeAttr("readonly");
        $("#status").val("");

        // hide button
        $("#deleteBtn").removeClass("d-none");
    }
});